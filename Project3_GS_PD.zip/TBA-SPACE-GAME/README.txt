HOW TO COMPILE AND RUN
------------------------
Compile: 
you can compile by typing "make" into the command line and then ./game.out

or

you can compile by typing g++ -std=c++11 -o game.out Game.cpp Location.cpp Map.cpp 
player.cpp spaceShip.cpp Enemy.cpp gameDriver.cpp in the command line and then ./game.out
------------------------
DEPENDENCIES
------------------------
The following files  must be in the same directory as the cpp files in 
order to compile:
Enemy.h
Location.h
Game.h
Map.h
Player.h
SpaceShip.h
------------------------
SUBMISSION INFORMATION
------------------------
CSCI1300 Fall 2021 Project 3
Author: Pandora Down and Greg Sinnott
Recitation 112- Maria Stull
November 24th 2021 
------------------------
ABOUT THIS PROJECT
------------------------
This project implements a game that allows a player to travel through space on a spaceship of there choosing 
and discover new planets. The player has a hundred year lifespan to explore space and after aging past that point they retire. 
